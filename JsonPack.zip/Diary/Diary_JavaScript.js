function start()
{
    //�e���v���[�g����������[�h
    var path = window.external.ThrowTemplatePath();
    var flame =document.getElementsByName("Tamplate");
    flame[0].value = path;
    
    //�ۑ���p�X����������[�h
    var foo = window.external.ThrowSavePath();
    var ooo =document.getElementsByName("PathOfSave");
    ooo[0].value = foo;
    
    //�e���v���[�g�����[�h
    var info = window.external.Load(flame[0].value);
    var obj = JSON.parse(info);
    
    //g �`���v�^�[�̒��̎�ʑI��
    var ChapterSelect = obj.Index.Contents.Chapter.sumTotal;
    for(var g=1;g<=ChapterSelect;g++){
        
        var ChapterName = obj.Index.Contents.Chapter["n"+String(g)]["name"];
        var ChapterSubject = obj.Index.Contents.Chapter["n"+String(g)]["Subject"];
        var ChapterSubstance = obj.Index.Contents.Chapter["n"+String(g)]["Substance"];
        var sbj = document.getElementsByName("Subject_"+ChapterName);
        var sbs = document.getElementsByName("Substance_"+ChapterName);
        sbj[0].innerHTML = ChapterSubject;
        sbs[0].innerHTML = ChapterSubstance;
        
        //i �������ڐ��ݒ�
        var initualTimes = obj.Index.Contents.Chapter["n"+String(g)]["initualTimes"];
        
        //j ���ڂ̒���form��
        var sumTotal = obj.Index.Contents.Chapter["n"+String(g)]["item"]["Questions"]["sumTotal"];
        for(var i=1;i<=initualTimes;i++){
            for(var j=1;j<=sumTotal;j++){
                var ChapterNumber = document.getElementsByName(ChapterName+"_"+String(i)+"_num");
                ChapterNumber[0].innerHTML = String(i);
                var Qwrite = document.getElementsByName(ChapterName+"_"+String(i)+"_Question"+String(j));
                Qwrite[0].innerHTML = obj.Index.Contents.Chapter["n"+String(g)]
                        ["item"]["Questions"]["n"+String(j)]["article"];
            }
        }
    }
}
window.onload = start;
//----------------------------------------------------
function PathOfSave_Botton_Click()
{
    var loadPath = window.external.OpenDirDialog();
    alert(loadPath);
    var POS= document.getElementsByName("PathOfSave");
    POS[0].value = loadPath;
}
function JsonSave(str)
{
    //�e���v���[�g�����[�h
    var temp =document.getElementsByName("Tamplate");
    var info = window.external.Load(temp[0].value);
    var TemplateObject = JSON.parse(info);
    
    //ChapSumTotal �`���v�^�[��
    var ChapSumTotal = TemplateObject.Index.Contents.Chapter.sumTotal;
    
    //Chapters �e���v���[�g�̃`���v�^�[������A�`���v�^�[�ԍ����i�[
    var Chapters = new Array();
    for(var k=1;k<=ChapSumTotal;k++){
        Chapters[k]=TemplateObject.Index.Contents.Chapter["n"+String(k)]["name"];
    }
    
    //name�ɂ���ă`���v�^�[��I������
    var chooseChap = 0;
    for(var g=1;g<=ChapSumTotal;g++){
        if(Chapters[g]==str){
            chooseChap=g;
        }
    }
    //----------------------------------------------------//
    //�����̍����̃f�[�^�����[�h
    var PoS =document.getElementsByName("PathOfSave");
    var LoadExistFile = window.external.Load(PoS[0].value);
    var JsonData = null;
    
    if(LoadExistFile!=""){
        //�����̃f�[�^�����݂���Ƃ�
        JsonData = JSON.parse(LoadExistFile);
        alert(JSON.stringify(JsonData));
    }else{
        //�����̃f�[�^�����݂��Ȃ���
        var JsonData = new Object();
        JsonData.QandA =new Object();
    }
    JsonData.QandA[str] =new Object();
    //----------------------------------------------------//
    
    //i �������ڐ��ݒ�
    var initualTimes = TemplateObject.Index.Contents.Chapter["n"+String(chooseChap)]["initualTimes"];
    
    //j ���ڂ̒���form��
    var sumTotal = TemplateObject.Index.Contents.Chapter["n"+String(chooseChap)]
                   ["item"]["Questions"]["sumTotal"];
    
    for(var i=1;i<=initualTimes;i++){
        JsonData.QandA[str][str+"_"+String(i)] =new Object();
        for(var j=1;j<=sumTotal;j++){
            JsonData.QandA[str][str+"_"+String(i)][str+"_"+String(i)+"_"+String(j)] =new Object();
            var Q11=document.getElementsByName(str+"_"+String(i)+"_Question"+String(j));
            var A11=document.getElementsByName(str+"_"+String(i)+"_Answer"+String(j));
            JsonData.QandA[str][str+"_"+String(i)][str+"_"+String(i)+"_"+String(j)].Q =Q11[0].innerHTML;
            JsonData.QandA[str][str+"_"+String(i)][str+"_"+String(i)+"_"+String(j)].A =A11[0].value;
        }
    }
    
    var mani = JSON.stringify(JsonData);
    var TEJson = document.getElementsByName(str+"_JsonString");
    TEJson[0].innerHTML = mani;
    
    var path = document.getElementsByName("PathOfSave");
    alert(path[0].value);
    window.external.Save(path[0].value,mani);
}
