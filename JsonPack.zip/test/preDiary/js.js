﻿var jsdata1 = 'testtesttest';
function JSfunc1(arg)
{
    alert('JSfunc1! : ' + arg);
}
function Q_entry_Button_Click()
{
    var Q01 = document.QuestionEntry.Q_entry01.value;
    var Q02 = document.QuestionEntry.Q_entry02.value;
    var Q03 = document.QuestionEntry.Q_entry03.value;
    document.getElementById("Quest_01").innerHTML=Q01;
    document.getElementById("Quest_02").innerHTML=Q02;
    document.getElementById("Quest_03").innerHTML=Q03;
}
function Json_show_Click()
{
    var Q01=document.getElementById("Quest_01").innerHTML;
    var Q02=document.getElementById("Quest_02").innerHTML;
    var Q03=document.getElementById("Quest_03").innerHTML;
    var A01 = document.QuestionAndAnswer.ans01.value;
    var A02 = document.QuestionAndAnswer.ans02.value;
    var A03 = document.QuestionAndAnswer.ans03.value;
    alert(Q01+A01+"\n"+Q02+A02+"\n"+Q03+A03+"\n");
    var obj = new Object();
    obj.QandA =new Object();
    obj.QandA["Quest_01"] =new Object();
    obj.QandA["Quest_02"] =new Object();
    obj.QandA["Quest_03"] =new Object();
    
    obj.QandA["Quest_01"].Q = Q01;
    obj.QandA["Quest_01"].A = A01;
    obj.QandA["Quest_02"].Q = Q02;
    obj.QandA["Quest_02"].A = A02;
    obj.QandA["Quest_03"].Q = Q03;
    obj.QandA["Quest_03"].A = A03;
    var str = JSON.stringify(obj);
    alert(str);
    document.JsonText.Json_show_Bar.value = str;
}
function preserveTo_Click()
{
    var foo = window.external.ThrowSavePath();
    alert(foo);
    document.Save.preserveTo_Bar.value = foo;
}
function preserve_Click()
{
    var path = document.Save.preserveTo_Bar.value;
    var json = document.JsonText.Json_show_Bar.value;
    window.external.Save(path,json);
}
function chooseFile_Botton_Click()
{
    var loadPath = window.external.OpenFileDialog();
    document.Read.chooseFile_bar.value = loadPath;
}
function chooseFileGo_Click()
{
    var path = document.Read.chooseFile_bar.value;
    var info = window.external.Road(path);
    alert(info);
    var obj = JSON.parse(info);
    document.QuestionEntry.Q_entry01.value = obj.Questions.Q1.Q;
    document.QuestionEntry.Q_entry02.value = obj.Questions.Q2.Q;
    document.QuestionEntry.Q_entry03.value = obj.Questions.Q3.Q;
}